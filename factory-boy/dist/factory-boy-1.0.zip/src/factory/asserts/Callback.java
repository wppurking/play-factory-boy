package factory.asserts;

public interface Callback {
	void run();
}
